<?php
include("header.php");
include("sidebar.php");
?>
<section id="main-content">
    <section class="wrapper" style="padding-top: 100px;"> 
           <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                   <a href="employeelogin.php"> <div class="info-box blue-bg">
                        
                        <b><div style="font-size: 25px; padding-top: 18px;">EMPLOYEE</div></b>
                                            
                    </div></a><!--/.info-box-->         
                </div><!--/.col-->
                
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                    <a href="loaderlogin.php"><div class="info-box purple-bg">
                        
                         <b><div style="font-size: 25px; padding-top: 18px;">LOADER</div></b>
                    </div></a><!--/.info-box-->         
                </div><!--/.col-->  
                
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                    <a href="truckprovider.php"><div class="info-box dark-bg">
                         <b><div style="font-size: 25px; padding-top: 18px;">PROVIDER</div></b>            
                    </div></a><!--/.info-box-->         
                </div><!--/.col-->
                
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                   <a href="truckdriver.php"> <div class="info-box green-bg">
                        
                          <b><div style="font-size: 25px; padding-top: 18px;">DRIVER</div></b>                    
                    </div></a><!--/.info-box-->         
                </div><!--/.col-->
                
            </div><!--/.row-->
    </section>
</section>
<?php
include("footer.php");
?>