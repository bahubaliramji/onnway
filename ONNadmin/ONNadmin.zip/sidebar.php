<body>
  <section id="container" class="">
     
      
      <header class="header dark-bg">
            <div class="toggle-nav">
                <div class="icon-reorder tooltips" data-original-title="Toggle Navigation" data-placement="bottom"></div>
            </div>

            <!--logo start-->
            <img src="logo.png" height=50px; widht=50px; />
            <!--logo end-->

            <div class="nav search-row" id="top_menu">
                <!--  search form start -->
                
                <!--  search form end -->                
            </div>

            <div class="top-nav notification-row">                
                    <li class="dropdown" style=" font-size: 25px;">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#" style="color:#fff;  font-size: 18px;">
                            Profile
                        </a>
                        <ul class="dropdown-menu extended logout">
                            <div class="log-arrow-up"></div>
                            <li class="eborder-top">
                                <a href="myprofile.php"> My Profile</a>
                            </li>
                            <li>
                                <a href="resetpassword.php"> Reset Password</a>
                            </li>
                            <li>
                                <a href="logout.php"> Logout</a>
                            </li>
    
                        </ul>
                    </li>
                    <!-- user login dropdown end -->
                </ul>
                <!-- notificatoin dropdown end-->
            </div>
      </header>      
      <!--header end-->

      <!--sidebar start-->
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu">                
                  <li >
                      <a class="" href="dashboard.php">
                          
                          <span>Dashboard</span>
                      </a>
                  </li>
                    <li >
                      <a class="" href="partload.php">
                          
                          <span>Part load quotes</span>
                      </a>
                  </li>
                   <li >
                      <a class="" href="fullload.php">
                          
                          <span>Full load quote</span>
                      </a>
                  </li>
                  <li>
                      <a class="" href="manageorder.php">
                         
                          <span>Post load request</span>
                      </a>
                  </li>
                  <li>
                      <a class="" href="loginmanagement.php">
                        
                          <span> Login Management</span>
                      </a>
                  </li>
                  
                  <li>
                      <a class="" href="trackorder.php">
                         
                          <span>Track booked order</span>
                      </a>
                  </li>
                  
                  <li>
                      <a class="" href="fullpostedtruck.php">
                         
                          <span>Full posted truck</span>
                      </a>
                  </li>
                  <li>
                      <a class="" href="partpostedtruck.php">
                         
                          <span>Part posted truck</span>
                      </a>
                  </li>
                  
                  
                  
                  <li>
                      <a class="" href="orderenquiry.php">
                          
                          <span>Order Enquiry</span>
                      </a>
                  </li>
                  <li>
                      <a class="" href="partloadenquiry.php">
                          
                          <span>Partload Enquiry</span>
                      </a>
                  </li>
                  <li>
                      <a class="" href="setting.php">
                          
                          <span>Setting</span>
                      </a>
                  </li>
                  <li>                     
                      <a class="" href="transportform.php">
                         
                          <span>Transport form</span>
                          
                      </a>
                                         
                  </li>
                             
                  
                  
                
                  
              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>
</section>