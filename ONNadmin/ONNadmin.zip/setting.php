<?php
include("header.php");
include("sidebar.php");
?>
<section id="main-content">
    <section class="wrapper" style="padding-top: 100px;"> 
           <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                   <a href="vehicleadding.php"> <div class="info-box blue-bg">
                        
                        <b><div style="font-size: 25px; padding-top: 18px;">ADD VEHICLE</div></b>
                                            
                    </div></a><!--/.info-box-->         
                </div><!--/.col-->
                
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                    <a href="material-table.php"><div class="info-box purple-bg">
                        
                         <b><div style="font-size: 25px; padding-top: 18px;">ADD MATERIAL</div></b>
                    </div></a><!--/.info-box-->         
                </div><!--/.col-->  
                
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                    <a href="route-estimate.php"><div class="info-box dark-bg">
                         <b><div style="font-size: 25px; padding-top: 18px;">ADD ROUTE</div></b>            
                    </div></a><!--/.info-box-->         
                </div><!--/.col-->
                
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                   <a href="#"> <div class="info-box green-bg">
                        
                          <b><div style="font-size: 25px; padding-top: 18px;">CALL CENTER</div></b>                    
                    </div></a><!--/.info-box-->         
                </div><!--/.col-->
                
            </div><!--/.row-->
    </section>
</section>
<?php
include("footer.php");
?>