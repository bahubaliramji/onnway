 <html>
 <head>
     <meta name="viewport" content="width=1024">
  <title>Search Engine Title Goes Here</title>
  <link rel="stylesheet" type="text/css" href="style1.css">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  
  </head>
  <body style="background-image: url('back.png'); background-repeat: no-repeat;">
 <div class="container" style="padding: 213px 0px 20px 20px; width: 235px; margin-right: 579px; ">
  <div class="row" style="padding: 10px 0px 0px 0px;">
    <div class="col-xs-6" style="padding: 0px 0px 0px 10px;"><div class="select" style="padding: 50px 20px 20px 20px; background-color: <?php if($_GET['div1']==1){ echo '#aaa'; } if($_GET['div1']==2){ echo '#f00'; } if($_GET['div1']==0) { echo '#fff'; } ?>;"></div></div>
    <div class="col-xs-6" style="padding: 0px 0px 0px 10px;"><div class="select" style="padding: 50px 20px 20px 20px; background-color: <?php if($_GET['div2']==1){ echo '#aaa'; } if($_GET['div2']==2){ echo '#f00'; } if($_GET['div2']==0) { echo '#fff'; } ?>; "></div></div> 
  </div>
    <div class="row" style="padding: 10px 0px 0px 0px;">
   <div class="col-xs-6" style="padding: 0px 0px 0px 10px;"><div class="select" style="padding: 50px 20px 20px 20px; background-color: <?php if($_GET['div3']==1){ echo '#aaa'; } if($_GET['div3']==2){ echo '#f00'; } if($_GET['div3']==0) { echo '#fff'; } ?>; "></div></div>
   <div class="col-xs-6" style="padding: 0px 0px 0px 10px;"><div class="select" style="padding: 50px 20px 20px 20px; background-color: <?php if($_GET['div4']==1){ echo '#aaa'; } if($_GET['div4']==2){ echo '#f00'; } if($_GET['div4']==0) { echo '#fff'; } ?>; "></div></div>
    </div>
    <div class="row" style="padding: 10px 0px 0px 0px;">
   <div class="col-xs-6" style="padding: 0px 0px 0px 10px;"><div class="select" style="padding: 50px 20px 20px 20px; background-color: <?php if($_GET['div5']==1){ echo '#aaa'; } if($_GET['div5']==2){ echo '#f00'; } if($_GET['div5']==0) { echo '#fff'; } ?>; "></div></div>
    <div class="col-xs-6" style="padding: 0px 0px 0px 10px;"><div class="select" style="padding: 50px 20px 20px 20px; background-color: <?php if($_GET['div6']==1){ echo '#aaa'; } if($_GET['div6']==2){ echo '#f00'; } if($_GET['div6']==0) { echo '#fff'; } ?>; "></div></div>
  </div>
    <div class="row" style="padding: 10px 0px 0px 0px;">
    <div class="col-xs-6" style="padding: 0px 0px 0px 10px;"><div class="select" style="padding: 50px 20px 20px 20px; background-color: <?php if($_GET['div7']==1){ echo '#aaa'; } if($_GET['div7']==2){ echo '#f00'; } if($_GET['div7']==0) { echo '#fff'; } ?>; "></div></div>
    <div class="col-xs-6" style="padding: 0px 0px 0px 10px;"><div class="select" style="padding: 50px 20px 20px 20px; background-color: <?php if($_GET['div8']==1){ echo '#aaa'; } if($_GET['div8']==2){ echo '#f00'; } if($_GET['div8']==0) { echo '#fff'; } ?>; "></div></div>
  </div>
 </div>
   </body>
   </html>