<?php
include("header.php");
include("sidebar.php");
?>
<section id="main-content">
    <section class="wrapper"> 
          hey
    </section>
</section>
<?php
include("footer.php");
?>